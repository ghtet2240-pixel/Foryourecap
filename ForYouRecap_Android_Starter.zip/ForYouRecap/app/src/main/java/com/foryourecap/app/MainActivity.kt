package com.foryourecap.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import java.io.IOException

class MainActivity : AppCompatActivity() {
    private var selectedUri: Uri? = null
    private lateinit var fileName: TextView
    private lateinit var recapButton: Button
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView

    // Change this to your deployed backend URL.
    // Example: https://your-domain.com/api/recap
    private val apiUrl = "https://YOUR-BACKEND.example/api/recap"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val uploadBox = findViewById<TextView>(R.id.uploadBox)
        fileName = findViewById(R.id.fileName)
        recapButton = findViewById(R.id.recapButton)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)

        uploadBox.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "video/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            startActivityForResult(intent, 100)
        }

        recapButton.setOnClickListener { uploadForRecap() }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
            selectedUri = data?.data
            fileName.text = selectedUri?.lastPathSegment ?: "Video selected"
            recapButton.isEnabled = selectedUri != null
            status.text = "Video ရွေးပြီးပါပြီ။ AUTO RECAP နှိပ်ပါ။"
        }
    }

    private fun uploadForRecap() {
        val uri = selectedUri ?: return
        progress.visibility = View.VISIBLE
        recapButton.isEnabled = false
        status.text = "Video ကို Server သို့တင်နေပါတယ်..."

        val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
        if (bytes == null) {
            finishRequest("Video ဖတ်မရပါ။")
            return
        }

        val body = bytes.toRequestBody("video/mp4".toMediaType())
        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("video", "upload.mp4", body)
            .addFormDataPart("language", "my")
            .addFormDataPart("format", "9:16")
            .build()

        val request = Request.Builder().url(apiUrl).post(requestBody).build()

        OkHttpClient().newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread { finishRequest("Server ချိတ်ဆက်မရပါ: ${e.message}") }
            }

            override fun onResponse(call: Call, response: Response) {
                val text = response.body?.string() ?: ""
                runOnUiThread {
                    finishRequest(if (response.isSuccessful) "Recap processing စတင်ပြီးပါပြီ။\n$text"
                                  else "Server error: ${response.code}")
                }
            }
        })
    }

    private fun finishRequest(message: String) {
        progress.visibility = View.GONE
        recapButton.isEnabled = selectedUri != null
        status.text = message
    }
}
