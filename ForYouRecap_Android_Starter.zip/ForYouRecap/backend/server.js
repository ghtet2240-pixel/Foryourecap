import express from "express";
import cors from "cors";
import multer from "multer";
import fs from "fs";
import path from "path";
import { randomUUID } from "crypto";

const app = express();
const upload = multer({ dest: "uploads/" });
app.use(cors());
app.use(express.json());

app.get("/health", (_req, res) => res.json({ ok: true, app: "ForYou Recap" }));

app.post("/api/recap", upload.single("video"), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: "No video uploaded" });

  const jobId = randomUUID();
  // Production pipeline to add next:
  // 1) validate duration <= 10 minutes with FFmpeg
  // 2) extract scenes / frames
  // 3) transcribe audio
  // 4) generate Burmese recap script
  // 5) generate voice-over
  // 6) render 9:16 video with captions and music
  // 7) return a downloadable MP4 URL
  //
  // Keep AI/provider keys on this server, never inside the Android APK.

  res.json({
    jobId,
    status: "queued",
    message: "Video received. Connect your AI + FFmpeg pipeline to finish the render."
  });
});

app.listen(process.env.PORT || 8080, () =>
  console.log(`ForYou Recap backend listening on ${process.env.PORT || 8080}`)
);
