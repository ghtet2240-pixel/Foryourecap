# ForYou Recap

Android starter project matching the supplied Auto Recap screenshot style.

## What is included
- Android upload screen
- MP4/MOV/WEBM/MKV video picker
- 10-minute product/UI limit shown in the interface
- Auto Recap button
- Multipart upload to a backend
- Node/Express backend starter
- GitHub Actions workflow for building a debug APK

## Important
The Android app must NOT contain private AI/API keys. Put provider keys on the backend.

## Build
Open this folder in Android Studio and build the `app` module.

Or push it to GitHub. The included workflow builds a debug APK automatically.

## Backend
```bash
cd backend
npm install
npm start
```

Then change `apiUrl` in `MainActivity.kt` to your HTTPS backend URL.

## Production pipeline
The backend placeholder is intentionally separated from the UI. A real recap service needs video validation, scene extraction, transcription, script generation, TTS, FFmpeg rendering, storage, and a job-status endpoint.
